-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema sneaker_database
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema sneaker_database
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `sneaker_database` DEFAULT CHARACTER SET utf8 ;
USE `sneaker_database` ;

-- -----------------------------------------------------
-- Table `sneaker_database`.`BRAND`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sneaker_database`.`BRAND` (
  `brand_id` INT NOT NULL AUTO_INCREMENT,
  `brand_name` VARCHAR(45) NULL,
  `brand_origin` VARCHAR(45) NULL,
  `created` DATETIME NULL,
  `creator` VARCHAR(45) NULL,
  PRIMARY KEY (`brand_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sneaker_database`.`DESIGNER`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sneaker_database`.`DESIGNER` (
  `designer_id` INT NOT NULL AUTO_INCREMENT,
  `designer_name` VARCHAR(45) NULL,
  PRIMARY KEY (`designer_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `sneaker_database`.`SNEAKER`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `sneaker_database`.`SNEAKER` (
  `sneaker_id` INT NOT NULL AUTO_INCREMENT,
  `sneaker_name` VARCHAR(45) NULL,
  `release_year` DATETIME NULL,
  `I_own` VARCHAR(45) NULL,
  `designer_id` INT NULL,
  `brand_id` INT NULL,
  PRIMARY KEY (`sneaker_id`),
  INDEX `brand_id_idx` (`brand_id` ASC) VISIBLE,
  INDEX `designer_id_idx` (`designer_id` ASC) VISIBLE,
  CONSTRAINT `brand_id`
    FOREIGN KEY (`brand_id`)
    REFERENCES `sneaker_database`.`BRAND` (`brand_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `designer_id`
    FOREIGN KEY (`designer_id`)
    REFERENCES `sneaker_database`.`DESIGNER` (`designer_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
