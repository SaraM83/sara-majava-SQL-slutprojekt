
const express = require('express');
const mysql = require('mysql2');  
const cors = require('cors'); 

const app = express();
const port = 4500; 
app.use(cors({
    origin : 'http://localhost:5500'
}));


app.listen(port, () => {  
    console.log('server listening on' + port); 
}); 

const db = mysql.createConnection({
    host : '',
    port : 0000, 
    user : '',
    password : '',
    database : 'sneaker_database'
}); 

db.connect((error) => {
    if (error) {
        throw error; 
    } 
}); 


app.get('/addnewsneaker', (request, response) => {
    let sql = 'INSERT INTO SNEAKER VALUES (DEFAULT, "' + 
    request.query.sneaker_name + '", "' + request.query.release_year + '", "' + 
    request.query.I_own + '", ' + request.query.designer_id + ', ' + request.query.brand_id + ');'; // var noga med plupparna!!!
    db.query(sql, (error, result) => {
        if (error) {
            throw error; 
        }
        console.log(result); 
        response.send('A new sneaker has been added'); 
    });  
});


app.get('/deletesneaker:id', (request, response) => { 
    let sql = 'DELETE FROM SNEAKER WHERE sneaker_id = ' + request.params.id + ';'; 
    db.query(sql, (error, result) => {
        if (error) {
            throw error; 
        }
        console.log(result); 
        response.send('Sneaker deleted'); 
    });  
});

app.get('/updatesneaker:id/:newname', (request, response) => { 
    let sql = 'UPDATE SNEAKER SET sneaker_name = "' + 
    request.params.newname + '" WHERE sneaker_id = ' + 
    request.params.id + ';'; 
    db.query(sql, (error, result) => {
        if (error) {
            throw error; 
        }
        console.log(result); 
        response.send('Sneaker has been changed'); 
    });  
});
 

app.get('/getsneakers', (request,response) => {
    let sql = 'SELECT * FROM SNEAKER';

    db.query(sql, (error, result) => {
        if (error) throw error; 

        console.log(result); 
        response.send(result); 
    }); 
}) 













